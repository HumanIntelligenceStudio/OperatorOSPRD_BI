# Content Creation Templates
## AI-Powered Content That Converts

### Hook Templates

#### Problem-Agitation-Solution
```
"Still [DOING HARD THING] manually? 
Here's how AI can [SOLVE PROBLEM] in [TIME FRAME]..."
```

#### Before & After
```
"From [NEGATIVE STATE] to [POSITIVE STATE] in [TIME PERIOD]
Here's exactly how I did it..."
```

#### Curiosity Gap
```
"The [SURPRISING THING] about [TOPIC] that [AUTHORITY FIGURES] don't want you to know..."
```

#### Number-Based
```
"[NUMBER] [CATEGORY] that will [BENEFIT] in [TIME FRAME]
(#[NUMBER] will shock you)"
```

### Value-First Content Templates

#### Tutorial Template
```
📚 TITLE: How to [ACHIEVE OUTCOME] with [TOOL/METHOD]

🎯 HOOK: [Problem/Desire Statement]

📝 STEPS:
1. [Step 1 with specific action]
2. [Step 2 with specific action]
3. [Step 3 with specific action]

💡 PRO TIP: [Advanced insight]

🔥 RESULTS: [Expected outcome]

❓ QUESTION: What's your biggest challenge with [TOPIC]?

#[RelevantHashtags]
```

#### Behind-the-Scenes Template
```
🎬 TITLE: Behind the scenes: [ACHIEVEMENT/PROCESS]

🎯 HOOK: [Vulnerability/Authenticity opener]

📊 THE REALITY:
• [Honest insight 1]
• [Honest insight 2]
• [Honest insight 3]

🛠️ TOOLS I USE:
• [Tool 1] - [Why it's useful]
• [Tool 2] - [Why it's useful]
• [Tool 3] - [Why it's useful]

📈 RESULTS: [Specific metrics/outcomes]

💭 LESSON: [Key takeaway]

#[RelevantHashtags]
```

#### Story Template
```
📖 TITLE: [Transformation/Journey Story]

🎯 HOOK: [Relatable struggle/moment]

📉 THE PROBLEM:
[Describe the challenge/pain point]

🔄 THE TURNING POINT:
[What changed everything]

📈 THE SOLUTION:
[Step-by-step what you did]

🎉 THE RESULT:
[Specific outcome/transformation]

💡 THE LESSON:
[Key insight for audience]

❓ QUESTION: [Engagement question]

#[RelevantHashtags]
```

### Platform-Specific Templates

#### Instagram Post Template
```
🎯 HOOK: [Attention-grabbing first line]

📝 VALUE:
• [Bullet point 1]
• [Bullet point 2]
• [Bullet point 3]

💡 KEY TAKEAWAY: [Main lesson]

🔥 ACTION STEP: [What to do next]

❓ QUESTION: [Engagement question]

---
📸 [Image description/credit]
🏷️ #[hashtag1] #[hashtag2] #[hashtag3]
```

#### TikTok Script Template
```
🎬 HOOK (0-3 seconds):
"[Surprising statement/question]"

📝 VALUE (3-23 seconds):
[Quick, actionable content]

🔥 CTA (23-30 seconds):
"[Clear next step]"

📱 ON-SCREEN TEXT:
• [Key point 1]
• [Key point 2]
• [Key point 3]

🎵 MUSIC: [Trending audio suggestion]
```

#### LinkedIn Post Template
```
🎯 HOOK: [Professional insight/question]

📊 CONTEXT:
[Industry background/personal experience]

💡 INSIGHT:
[Key lesson/strategy]

📈 IMPLEMENTATION:
[How to apply this]

🔮 FUTURE IMPACT:
[Why this matters]

❓ QUESTION: [Professional discussion starter]

#[ProfessionalHashtags]
```

### Email Templates

#### Welcome Email
```
Subject: Welcome to [YOUR BRAND] - Here's your first AI win 🚀

Hi [NAME],

Welcome to the [YOUR BRAND] family! I'm [YOUR NAME], and I'm thrilled you've decided to join [NUMBER] other entrepreneurs transforming their businesses with AI.

Here's what you can expect:
• [Benefit 1]
• [Benefit 2]
• [Benefit 3]

To get you started, here's your first AI win:
[PROVIDE IMMEDIATE VALUE]

Your first action step: [CLEAR NEXT STEP]

Questions? Just reply to this email.

Best,
[YOUR NAME]

P.S. [PERSONAL NOTE/OFFER]
```

#### Value-First Email
```
Subject: [SPECIFIC BENEFIT] in [TIME FRAME]

Hi [NAME],

[PERSONAL/RELEVANT OPENER]

Here's what I want to share with you today:
[MAIN VALUE/INSIGHT]

How to implement this:
1. [Step 1]
2. [Step 2]
3. [Step 3]

Expected result: [OUTCOME]

Try this and let me know how it goes!

[YOUR NAME]

P.S. [ADDITIONAL VALUE/SOFT OFFER]
```

### Content Calendar Template

#### Weekly Content Plan
```
MONDAY - Motivation/Inspiration
• Post type: [Story/Quote/Transformation]
• Platform: [Primary platform]
• Hook: [Motivational opener]
• CTA: [Engagement focus]

TUESDAY - Tutorial/Education
• Post type: [How-to/Tips/Guide]
• Platform: [Educational platform]
• Hook: [Problem/Solution opener]
• CTA: [Learning focus]

WEDNESDAY - Behind-the-Scenes
• Post type: [Process/Journey/Reality]
• Platform: [Authentic platform]
• Hook: [Vulnerability opener]
• CTA: [Community focus]

THURSDAY - Tool/Resource
• Post type: [Review/Recommendation/Demo]
• Platform: [Value-focused platform]
• Hook: [Solution opener]
• CTA: [Resource focus]

FRIDAY - Community/Engagement
• Post type: [Question/Poll/Challenge]
• Platform: [Interactive platform]
• Hook: [Community opener]
• CTA: [Engagement focus]

SATURDAY - Success/Results
• Post type: [Case study/Testimonial/Wins]
• Platform: [Trust-building platform]
• Hook: [Social proof opener]
• CTA: [Social proof focus]

SUNDAY - Personal/Lifestyle
• Post type: [Life/Values/Balance]
• Platform: [Personal platform]
• Hook: [Personal opener]
• CTA: [Connection focus]
```

### AI-Assisted Content Creation Process

#### Step 1: Idea Generation
```
AI Prompt: "Generate 10 content ideas for [YOUR NICHE] that address [SPECIFIC PROBLEM] for [TARGET AUDIENCE]"
```

#### Step 2: Hook Creation
```
AI Prompt: "Create 5 attention-grabbing hooks for a post about [TOPIC] targeting [AUDIENCE] on [PLATFORM]"
```

#### Step 3: Content Development
```
AI Prompt: "Write a [PLATFORM] post about [TOPIC] using this hook: [HOOK]. Include [SPECIFIC REQUIREMENTS]"
```

#### Step 4: Optimization
```
AI Prompt: "Optimize this content for [PLATFORM] to increase [GOAL]: [CONTENT]"
```

#### Step 5: Repurposing
```
AI Prompt: "Adapt this [ORIGINAL PLATFORM] post for [NEW PLATFORM]: [CONTENT]"
```

---

## Content Performance Tracking

### Key Metrics to Monitor
- [ ] Reach and impressions
- [ ] Engagement rate
- [ ] Click-through rate
- [ ] Conversion rate
- [ ] Follower growth rate

### Weekly Content Review
- [ ] Top performing posts
- [ ] Lowest performing posts
- [ ] Engagement patterns
- [ ] Audience feedback
- [ ] Optimization opportunities

---

*Use these templates to create consistent, high-converting content for your AI income streams.*
